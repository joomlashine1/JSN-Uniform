<?php
/**
 * @version    $Id$
 * @package    JSN_Uniform
 * @author     JoomlaShine Team <support@joomlashine.com>
 * @copyright  Copyright (C) @JOOMLASHINECOPYRIGHTYEAR@ JoomlaShine.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */

defined('_JEXEC') or die('Restricted access');

class JSNUFPayment_2CheckoutHelper2CheckoutStandard
{
	private $_apiHostname = '';

	private $_apiVendorID = '';

	private $_secretWord = '';

	private $_paymentConfig = null;

	private $_currency = array();

	/**
	 * Contructor
	 * @param array $_currency			The currency list
	 * @param object $_paymentConfig	The payment configuration
	 */
	public function __construct($_currency, $_paymentConfig)
	{
		$this->_paymentConfig = $_paymentConfig;
		$this->_currency = $_currency;

		if (@$this->_paymentConfig->test_mode)
		{
			//$this->_apiHostname  = 'https://sandbox.2checkout.com/checkout/spurchase';
			$this->_apiHostname  = 'https://www.2checkout.com/checkout/purchase';

			$this->_apiVendorID  = $this->_paymentConfig->two_checkout_sandbox_vendor_id;
			$this->_secretWord   = $this->_paymentConfig->two_checkout_sandbox_secret_word;
		}
		else
		{
			$this->_apiHostname  = 'https://www.2checkout.com/checkout/purchase';
			$this->_apiVendorID  = $this->_paymentConfig->two_checkout_live_vendor_id;
			$this->_secretWord   = $this->_paymentConfig->two_checkout_live_secret_word;
		}
	}

	/**
	 *	Insert Payment Log
	 *
	 * @param (int) $sub_id		The submission ID
	 *
	 * @return void
	 */
    public function insertPaymentLog($sub_id)
    {
    	$params = (array) $this->_paymentConfig;

    	$db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->insert($db->quoteName("#__jsn_uniform_payment_2checkout_logs"));
        $query->columns($db->quoteName(array('submission_id', 'log_currency')));
        $query->values(implode(',', array($sub_id, $db->quote($params['two_checkout_currency']))));
        $db->setQuery($query);
        $db->execute();
    }

	/**
	 * Post data to  Payment Gateway
	 *
	 * @param ArrayObject $data			the date are posted to payment gateway
	 * @param ArrayObject $dataField	the field list
	 * @param int $submissionID	The submission ID
	 *
	 * @return bool
	 */
	public function processToPostPaymentGateway($data, $dataField, $submissionID)
	{
		$data 		= $this->_prepareData($data, $dataField, $submissionID);
		$this->insertPaymentLog($submissionID);
		echo $this->_render2CheckoutInlineForm($data);
		return true;

	}

	/**
	 * Render HTML form to post to Payment Gateway
	 *
	 * @param array $data	The data to render into html
	 * @return string
	 */
	private function _render2CheckoutInlineForm($data)
	{
		$lang 			= JFactory::getLanguage();
		$lang->load('plg_uniform_payment_2checkout', JPATH_BASE . '/administrator');

		$html = '<div class="ui-widget-overlay">
					  <div class="img-box-loading">
					    <img id="img-loading-uiwindow-1" class="imgLoading" src="'. JURI::base() .'/plugins/uniform/payment_2checkout/assets/img/icon-24-dark-loading-circle.gif">
					  </div>
					  <div class="you-are-being-redirected">
					  	' . JText::_('PLG_JSNUNIFORM_PAYMENT_2CHECKOUT_YOU_ARE_BEING_REDIRECTED') . '
					  </div>
				  </div>';
		$html .= '<form action="'.$this->_apiHostname.'" method="post" id="jsnuf-2checkoutstandard" target="_parent">';

		foreach($data as $name => $value)
		{
			if ($name == 'checkout_item')
			{
				foreach ($value as $key=>$item)
				{
					$html .= '<input type="hidden" name="'.trim($key) .'" value="'. trim($item).'">';
				}
			}
			else
			{
				$html .= '<input type="hidden" name="'.trim($name).'" value="'. htmlspecialchars(trim($value), ENT_COMPAT, 'UTF-8').'">';
			}
		}

		$html .= '</form>';

		$html .= '
				<script>
					document.getElementById("jsnuf-2checkoutstandard").submit();
				</script>';
		echo '<link rel="stylesheet" href="'. JURI::base() .'/plugins/uniform/payment_2checkout/assets/css/jsnpayment_2checkout.css">';

		return $html;
	}

	/**
	 * prepare and process data before submit to Payment Gateway
	 * @param array $data
	 *
	 * @return array
	 */
	private function _prepareData($data, $dataField, $subId)
	{
		$params 		= (array) $this->_paymentConfig;
		$submitData 	= array();
		$curencyData 	= $this->_currency[$params['two_checkout_currency']];

		$curencyFormat 	= new JSNUniFormCurrencyHelper($params['two_checkout_currency'], $curencyData['currency_decimals'], $curencyData['currency_decimal_symbol'], $curencyData['currency_thousands_separator'], $curencyData['currency_symbol'], $params['two_checkout_position_symbol']);

		$total 			= (float) $data['jsn_form_total_money']['form_payment_money_value'];

		if (count((array)$dataField))
		{
			$fieldList = $this->_getFormFields((int) $data['form_id']);

			$index = 1;
			foreach ($dataField as $key => $value)
			{
				$tmpFieldObject = new stdClass;
				$tmpFieldObject->field_settings = isset($fieldList[$value['field_id']]) ? $fieldList[$value['field_id']] : '';
				$fieldSettings = array('' => $tmpFieldObject);

				foreach ($fieldSettings as $fieldSetting)
				{
					$itemSettings = json_decode($fieldSetting->field_settings);
					if (!empty($itemSettings->options->paymentMoneyValue) && $itemSettings->options->paymentMoneyValue == 'Yes')
					{

						if (!empty($value['submission_data_value']))
						{
							if ($value['field_type'] == 'checkboxes' || $value['field_type'] == 'dropdown' || $value['field_type'] == 'choices')
							{

							}

							if ($value['field_type'] == 'checkboxes' || $value['field_type'] == 'list' )
							{
								$items = json_decode($value['submission_data_value']);
								foreach($items as $item){
									$value['submission_data_value'] = $item;
									$moneyValue = str_replace(',', '.',$value['submission_data_value']);
									$tmpMoneyValue = explode('|', $moneyValue);
									$quantityValue = trim(end($tmpMoneyValue));
									$moneyValue = trim($tmpMoneyValue[1]);
									$expSubmitsionDataValue = explode('|', $value['submission_data_value']);
									$title = trim($value['field_title']) . ':' . trim(@$expSubmitsionDataValue[0]);
									$submitData = array_merge($submitData,array('item_name_'.$index => $title, 'item_number_'.$index => '1', 'amount_'.$index => (float) $moneyValue, 'quantity_'.$index => $quantityValue));
									$index++;
								}
							}
						}
					}
				}

				foreach ($fieldSettings as $fieldSettingSpc)
				{
					$itemSettings = json_decode($fieldSettingSpc->field_settings);
					if (!empty($itemSettings->options->paymentMoneyValue) && $itemSettings->options->paymentMoneyValue == 'Yes')
					{
						if (!empty($value['submission_data_value']))
						{
							if ($value['field_type'] != 'checkboxes' && $value['field_type'] != 'list' )
							{
								$title = $value['field_title'];
								$moneyValue = str_replace(',', '.', $value['submission_data_value']);
								$tmpMoneyValue = explode('|', $moneyValue);
								$quantityValue = trim(end($tmpMoneyValue));
								$moneyValue = trim($tmpMoneyValue[1]);
								if ($value['field_type'] == 'dropdown' || $value['field_type'] == 'choices')
								{
									$expSubmitsionDataValue = explode('|', $value['submission_data_value']);
									$title = trim($value['field_title']) . ':' . trim(@$expSubmitsionDataValue[0]);
								}
								if ($value['field_type'] == 'number' || $value['field_type'] == 'currency')
								{
									$moneyValue = str_replace(',', '.', $value['submission_data_value']);
									$quantityValue = '1';
								}
								$submitData = array_merge($submitData, array('item_name_' . $index => $title, 'item_number_' . $index => '1', 'amount_' . $index => (float) $moneyValue, 'quantity_' . $index => $quantityValue));
								$index++;
							}
						}
					}
				}
			}
		}

		$config 	= JFactory::getConfig();
		$secret 	= $config->get('secret');
		$token 		= JSession::getFormToken();
		$returnUrl 	= JURI::base() . 'index.php?option=com_uniform&form_id=' . $data['form_id'] . '&secret_key=' . md5($secret) .'&method=payment_2checkout&view=paymentgateway&task=paymentgateway.postback&submission_id=' . $subId;

		$fields 	= array();

		if (count((array)$submitData))
		{

			for ($i = 0 ; $i < $index; $i++)
			{
				if (isset($submitData['item_name_' . ($i + 1)])
						&& isset($submitData['quantity_' . ($i + 1)])
						&& isset($submitData['amount_' . ($i + 1)])
						&& isset($submitData['item_number_' . ($i + 1)]))
				{
					$tempNameItem 		= $submitData['item_name_' . ($i + 1)];
					$tempQuantityItem 	= $submitData['quantity_' . ($i + 1)];
					$tempAmountItem 	= $submitData['amount_' . ($i + 1)];

					/*$tempNameItemExplode = explode(":", $tempNameItem);
					if (count((array)$tempNameItemExplode) > 1)
					{
						$tempNameItem = $tempNameItemExplode[1];
					}*/

					$fields['checkout_item']['li_'.$i.'_type']     = 'product';
					$fields['checkout_item']['li_'.$i.'_name']     = $this->_characterLimiter($tempNameItem, 125);
					$fields['checkout_item']['li_'.$i.'_price']    = $tempAmountItem;
					$fields['checkout_item']['li_'.$i.'_quantity'] = $tempQuantityItem;
					$fields['checkout_item']['li_'.$i.'_tangible'] = 'N';
				}
			}
		}

		$invoiceNumber 					= $this->_generateInvoiceNumber();
		$fields['mode'] 				= '2CO';
		$fields['sid'] 					= (string) $this->_apiVendorID;
		$fields['currency_code'] 		= $params['two_checkout_currency'];
		$fields['x_receipt_link_url'] 	= $returnUrl;
		$fields['merchant_order_id'] 	= $invoiceNumber;
		$fields['purchase_step'] 		= 'review-cart';
		//$fields['total_amount'] 		= $data['subtotal_amount'];
		$fields['total_amount'] 		= $total;
		if (@$this->_paymentConfig->test_mode)
		{
			$fields['demo'] 		= 'Y';
		}
		// Check if extra fee is set?
		/*if (isset($data['extra_fee_amount']) && $data['extra_fee_amount'] > 0)
		{
			$fields['checkout_item']['li_0_startup_fee'] = $data['extra_fee_amount'] / $fields['checkout_item']['li_0_quantity'];
			$fields['total_amount'] = $data['total_includes_extra_fee'];
		}*/

		return $fields;

	}

	/**
	 * Check payment gateway is configured correctly
	 * @return bool
	 */
	public function checkPaymentGatewayValid()
	{

		if (@!is_null($this->_paymentConfig->test_mode))
		{
			if ($this->_paymentConfig->test_mode)
			{
				if((string) $this->_secretWord == '' || (string) $this->_apiHostname == '' || (string) $this->_apiVendorID == '')
				{
					return false;
				}
			}
			else
			{
				if ((string) $this->_secretWord == '' || (string) $this->_apiHostname == '' || (string) $this->_apiVendorID == '')
				{
					return false;
				}
			}
			return true;
		}

		return false;
	}

	/**
	 * Get the field list of a form
	 *
	 * @param int $formID The form ID
	 *
	 * @return ArrayObject;
	 */
	private function _getFormFields($formID)
	{
		$rfields = array();
		$db 	= JFactory::getDbo();
		$query 	= $db->getQuery(true);
		$query->select('*');
		$query->from('#__jsn_uniform_fields');
		$query->where('form_id='. (int) $formID);
		$db->setQuery($query);
		$fields = $db->loadObjectList();

		if (count((array)$fields))
		{
			foreach ($fields as $field)
			{
				$rfields[$field->field_id] = $field->field_settings;
			}
		}

		return $rfields;
	}

	/**
	 * Generate Invoice Number
	 * @return string
	 */
	private function _generateInvoiceNumber()
	{
		$length		 	= 4;
		$chars		  	= 'abcdefghijklmnopqrstuvwxyz';
		$chars_length 	= (strlen($chars) - 1);
		$string		 	= $chars[rand(0, $chars_length)];
		for ($i	= 1; $i < $length; $i = strlen($string))
		{
			$r  = $chars[rand(0, $chars_length)];
			if ($r != $string[$i - 1])
				$string .= $r;
		}
		$fullString = dechex(time() + mt_rand(0, 10000000)) . $string;
		$result	  = strtoupper(substr($fullString, 2, 10));
		return $result;
	}
	/**
	 * Method to verify payment status.
	 *
	 * @param   array  $post  The verifed data
	 *
	 * @return  bool  true/false
	 */
	public function verifyGatewayResponse($post)
	{

		// verify transaction
		$hashSecretWord = $this->_secretWord;
		$hashSid        = $this->_apiVendorID;
		$hashTotal      = $post['total'];
		//$hashTotal		= (number_format((float) $hashTotal, 2, '.', ''));
		if (@$this->_paymentConfig->test_mode)
		{
			$hashOrder = 1;
		}
		else
		{
			$hashOrder = $post['order_number']; //2Checkout Order Number
		}
		$stringToHash   = strtoupper(md5($hashSecretWord . $hashSid . $hashOrder . $hashTotal));

		if ($stringToHash != $post['key'])
		{
			return false;
		}
		else
		{
			$this->_updatePaymentLog($post);
			$this->_sendMail($post);
			return true;
		}
	}

	/**
	 * Send email
	 *
	 * @param array $post	the post data
	 *
	 * @return boole
	 */
	private function _sendMail($post)
	{
		if (!class_exists('JSNUniFormEmailHelper')) return false;
		// only send email when transaction done

		if (isset($this->_paymentConfig->receive_confirmation_of_successful_transaction))
		{
			if ($this->_paymentConfig->receive_confirmation_of_successful_transaction == '1')
			{
				$objJSNUniFormEmailHelper = new JSNUniFormEmailHelper;
				$objJSNUniFormEmailHelper->prepareDataForEmail($post);
			}
		}

		return true;
	}

	/**
	 * Limit the number of string is showed
	 *
	 * @param string $str	The string to be processed
	 * @param number $limit	The number of string is showed
	 * @return string
	 */
	private function _characterLimiter($str, $limit = 0)
	{
		$str = strip_tags(trim($str));

		if (function_exists("mb_substr"))
		{

			$str = mb_substr($str, 0, $limit, 'UTF-8');
		}
		else
		{
			$str = substr($str, 0, $limit);
		}
		return $str;
	}

	/**
	 * Update transaction log. Set status, amount, currency
	 * @param array $post
	 *
	 */
	private function _updatePaymentLog($post)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$fields = array(
				$db->quoteName('log_status') . ' = ' . $db->quote('successful'),
				$db->quoteName('log_amount') . ' = ' . $db->quote($post['total_amount']),
				$db->quoteName('log_currency') . ' = ' . $db->quote($post['currency_code'])
		);
		$conditions = array(
				$db->quoteName('submission_id') . ' = ' . $post['submission_id']
		);
		$query->update($db->quoteName("#__jsn_uniform_payment_2checkout_logs"));
		$query->set($fields);
		$query->where($conditions);
		$db->setQuery($query);
		$db->execute();
	}
}

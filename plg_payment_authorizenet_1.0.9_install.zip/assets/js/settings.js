/**
 * @version    $Id$
 * @package    JSN_Uniform
 * @author     JoomlaShine Team <support@joomlashine.com>
 * @copyright  Copyright (C) @JOOMLASHINECOPYRIGHTYEAR@ JoomlaShine.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */
( function ($) {
    "use strict";
    $(window).load(function () {
        var form = $('.paymentgateway-settings #profile-form'),
            test_mode = $("input[name='jform[test_mode]']:checked"),
            payment = $("select[name='jform[payment_product]']");
        if (test_mode.val() == '1')
        {
        	form.find('ul#jsn-uniform-authorizenetTabs li a[href=#apilive]').parents().removeClass('active')
            form.find('ul#jsn-uniform-authorizenetTabs li a[href=#apisandbox]').parents().addClass('active')
            form.find('div#jsn-uniform-authorizenetContent div#apilive').removeClass('active')
            form.find('div#jsn-uniform-authorizenetContent div#apisandbox').addClass('active')
        }

        $("input[name='jform[test_mode]']").on('change', function(){

                if($(this).val() == '1'){
                	form.find('ul#jsn-uniform-authorizenetTabs li a[href=#apilive]').parents().removeClass('active')
                    form.find('ul#jsn-uniform-authorizenetTabs li a[href=#apisandbox]').parents().addClass('active')
                    form.find('div#jsn-uniform-authorizenetContent div#apilive').removeClass('active')
                    form.find('div#jsn-uniform-authorizenetContent div#apisandbox').addClass('active')

                }
                else
                {
                	form.find('ul#jsn-uniform-authorizenetTabs li a[href=#apilive]').parents().addClass('active')
                    form.find('ul#jsn-uniform-authorizenetTabs li a[href=#apisandbox]').parents().removeClass('active')
                    form.find('div#jsn-uniform-authorizenetContent div#apilive').addClass('active')
                    form.find('div#jsn-uniform-authorizenetContent div#apisandbox').removeClass('active')

                }

            }

        );

    });

})((typeof JoomlaShine != 'undefined' && typeof JoomlaShine.jQuery != 'undefined') ? JoomlaShine.jQuery : jQuery);

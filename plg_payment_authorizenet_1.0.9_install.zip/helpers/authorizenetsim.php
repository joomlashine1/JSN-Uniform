<?php
/**
 * @version    $Id$
 * @package    JSN_Uniform
 * @author     JoomlaShine Team <support@joomlashine.com>
 * @copyright  Copyright (C) @JOOMLASHINECOPYRIGHTYEAR@ JoomlaShine.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */

defined('_JEXEC') or die('Restricted access');

class JSNUFPayment_AuthorizeNetHelperAuthorizeNetSim
{
	private $_apiHostname = '';

	private $_apiLoginID = '';

	private $_apiTransactionKey = '';

	private $_apiMD5Hash = '';

	private $_signatureKey = '';

	private $_paymentConfig = null;

	private $_currency = array();

	protected $_authorizenetParams = array(
			"version" => "3.1",
			"relay_response" => "FALSE",
	);

	/**
	 * Contructor
	 * @param array $_currency			The currency list
	 * @param object $_paymentConfig	The payment configuration
	 */
	public function __construct($_currency, $_paymentConfig)
	{
		$this->_paymentConfig = $_paymentConfig;
		$this->_currency = $_currency;

		if (@$this->_paymentConfig->test_mode)
		{
			if ((string) @ $this->_paymentConfig->authorizenet_sandbox_api_hostname == '')
			{
				$this->_apiHostname = 'https://test.authorize.net/gateway/transact.dll';
			}
			else
			{
				$this->_apiHostname	= $this->_paymentConfig->authorizenet_sandbox_api_hostname;
			}

			$this->_apiLoginID 			= @ $this->_paymentConfig->authorizenet_sandbox_api_loginid;
			//$this->_apiTransactionKey 	= $this->_paymentConfig->authorizenet_sandbox_api_transaction_key;
			//$this->_apiMD5Hash	 		= $this->_paymentConfig->authorizenet_sandbox_api_md5_hash;
			$this->_signatureKey	 	= @ $this->_paymentConfig->authorizenet_sandbox_api_signature_key;
		}
		else
		{
			if ((string) @ $this->_paymentConfig->authorizenet_live_api_hostname == '')
			{
				$this->_apiHostname = 'https://secure2.authorize.net/gateway/transact.dll';
			}
			else
			{
				$this->_apiHostname	= @ $this->_paymentConfig->authorizenet_live_api_hostname;
			}

			$this->_apiLoginID 			= @ $this->_paymentConfig->authorizenet_live_api_loginid;
			//$this->_apiTransactionKey 	= $this->_paymentConfig->authorizenet_live_api_transaction_key;
			//$this->_apiMD5Hash	 		= $this->_paymentConfig->authorizenet_live_api_md5_hash;
			$this->_signatureKey	 	= @ $this->_paymentConfig->authorizenet_live_api_signature_key;
		}


	}

	/**
	 *	Insert Payment Log
	 *
	 * @param (int) $sub_id		The submission ID
	 *
	 * @return void
	 */
    public function insertPaymentLog($sub_id)
    {
    	$params = (array) $this->_paymentConfig;

    	$db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->insert($db->quoteName("#__jsn_uniform_payment_authorizenet_logs"));
        $query->columns($db->quoteName(array('submission_id', 'log_currency')));
        $query->values(implode(',', array($sub_id, $db->quote($params['authorizenet_currency']))));
        $db->setQuery($query);
        $db->execute();
    }

	/**
	 * Post data to  Payment Gateway
	 *
	 * @param ArrayObject $data			the date are posted to payment gateway
	 * @param ArrayObject $dataField	the field list
	 * @param int $submissionID	The submission ID
	 *
	 * @return bool
	 */
	public function processToPostPaymentGateway($data, $dataField, $submissionID)
	{
		$data 		= $this->_prepareData($data, $dataField, $submissionID);
		$this->insertPaymentLog($submissionID);
		echo $this->_renderSIMAuthorizeNetForm($data);
		return true;

	}

	/**
	 * Render HTML form to post to Payment Gateway
	 *
	 * @param array $data	The data to render into html
	 * @return string
	 */
	private function _renderSIMAuthorizeNetForm($data)
	{
		$lang 			= JFactory::getLanguage();
		$lang->load('plg_uniform_payment_authorizenet', JPATH_BASE . '/administrator');

		$html = '<div class="ui-widget-overlay">
					  <div class="img-box-loading">
					    <img id="img-loading-uiwindow-1" class="imgLoading" src="'. JURI::base() .'/plugins/uniform/payment_authorizenet/assets/img/icon-24-dark-loading-circle.gif">
					  </div>
					  <div class="you-are-being-redirected">
					  	' . JText::_('PLG_JSNUNIFORM_PAYMENT_AUTHORIZENET_YOU_ARE_BEING_REDIRECTED') . '
					  </div>
				  </div>';
		$html .= '<form action="'.$this->_apiHostname.'" method="post" id="jsnuf-authorizenetSIM" target="_parent">';
		foreach($data as $name => $value)
		{
			if ($name == 'x_line_item')
			{
				foreach ($value as $item)
				{
					$html .= '<input type="hidden" name="'.trim($name) .'" value="'. trim($item).'">';
				}
			}
			else
			{
				$html .= '<input type="hidden" name="'.trim($name).'" value="'. htmlspecialchars(trim($value), ENT_COMPAT, 'UTF-8').'">';
			}
		}
		$html .= '</form>';

		$html .= '
				<script>
					document.getElementById("jsnuf-authorizenetSIM").submit();
				</script>';
		echo '<link rel="stylesheet" href="'. JURI::base() .'/plugins/uniform/payment_authorizenet/assets/css/jsnpayment_authorizenet.css">';

		return $html;
	}

	/**
	 * prepare and process data before submit to Payment Gateway
	 * @param array $data
	 *
	 * @return array
	 */
	private function _prepareData($data, $dataField, $subId)
	{
		$params 		= (array) $this->_paymentConfig;
		$submitData 	= array();
		$curencyData 	= $this->_currency[$params['authorizenet_currency']];

		$curencyFormat 	= new JSNUniFormCurrencyHelper($params['authorizenet_currency'], $curencyData['currency_decimals'], $curencyData['currency_decimal_symbol'], $curencyData['currency_thousands_separator'], $curencyData['currency_symbol'], $params['authorizenet_position_symbol']);
		$total 			= (float) $data['jsn_form_total_money']['form_payment_money_value'];
		//$curencyFormat->getFormattedCurrency($data['jsn_form_total_money']['form_payment_money_value']);

		if (count((array)$dataField))
		{
			$fieldList = $this->_getFormFields((int) $data['form_id']);

			$index = 1;
			foreach ($dataField as $key => $value)
			{
				$tmpFieldObject = new stdClass;
				$tmpFieldObject->field_settings = isset($fieldList[$value['field_id']]) ? $fieldList[$value['field_id']] : '';
				$fieldSettings = array('' => $tmpFieldObject);

				foreach ($fieldSettings as $fieldSetting)
				{
					$itemSettings = json_decode($fieldSetting->field_settings);
					if (!empty($itemSettings->options->paymentMoneyValue) && $itemSettings->options->paymentMoneyValue == 'Yes')
					{

						if (!empty($value['submission_data_value']))
						{
							if ($value['field_type'] == 'checkboxes' || $value['field_type'] == 'dropdown' || $value['field_type'] == 'choices')
							{

							}

							if ($value['field_type'] == 'checkboxes' || $value['field_type'] == 'list' )
							{
								$items = json_decode($value['submission_data_value']);
								foreach($items as $item){
									$value['submission_data_value'] = $item;
									$moneyValue = str_replace(',', '.',$value['submission_data_value']);
									$tmpMoneyValue = explode('|', $moneyValue);
									$quantityValue = trim(end($tmpMoneyValue));
									$moneyValue = trim($tmpMoneyValue[1]);
									$expSubmitsionDataValue = explode('|', $value['submission_data_value']);
									$title = trim($value['field_title']) . ':' . trim(@$expSubmitsionDataValue[0]);
									$submitData = array_merge($submitData,array('item_name_'.$index => $title, 'item_number_'.$index => '1', 'amount_'.$index => (float) $moneyValue, 'quantity_'.$index => $quantityValue));
									$index++;
								}
							}
						}
					}
				}

				foreach ($fieldSettings as $fieldSettingSpc)
				{
					$itemSettings = json_decode($fieldSettingSpc->field_settings);
					if (!empty($itemSettings->options->paymentMoneyValue) && $itemSettings->options->paymentMoneyValue == 'Yes')
					{
						if (!empty($value['submission_data_value']))
						{
							if ($value['field_type'] != 'checkboxes' && $value['field_type'] != 'list' )
							{
								$title = $value['field_title'];
								$moneyValue = str_replace(',', '.', $value['submission_data_value']);
								$tmpMoneyValue = explode('|', $moneyValue);
								$quantityValue = trim(end($tmpMoneyValue));
								$moneyValue = trim($tmpMoneyValue[1]);
								if ($value['field_type'] == 'dropdown' || $value['field_type'] == 'choices')
								{
									$expSubmitsionDataValue = explode('|', $value['submission_data_value']);
									$title = trim($value['field_title']) . ':' . trim(@$expSubmitsionDataValue[0]);
								}
								if ($value['field_type'] == 'number' || $value['field_type'] == 'currency')
								{
									$moneyValue = str_replace(',', '.', $value['submission_data_value']);
									$quantityValue = '1';
								}
								$submitData = array_merge($submitData, array('item_name_' . $index => $title, 'item_number_' . $index => '1', 'amount_' . $index => (float) $moneyValue, 'quantity_' . $index => $quantityValue));
								$index++;
							}
						}
					}
				}
			}
		}

		$token 		= JSession::getFormToken();
		$config 	= JFactory::getConfig();
		$secret 	= $config->get('secret');
		$returnUrl 	= JURI::base() . 'index.php?option=com_uniform&form_id=' . $data['form_id'] . '&secret_key=' . md5($secret) . '&method=payment_authorizenet&view=paymentgateway&task=paymentgateway.postback&submission_id=' . $subId;

		if (!isset($params['archive_cancel_transaction']) || $params['archive_cancel_transaction'] == "1")
		{
			$cancelUrl = $params['authorizenet_cancel_url'] != '' ? $params['authorizenet_cancel_url'] : JURI::base();
		}
		else
		{
			$cancelUrl = JURI::base() . 'index.php?option=com_uniform&form_id=' . $data['form_id'] . '&submission_id=' . $subId . '&secret_key=' . md5($secret) . '&' . $token . '=1' . '&method=payment_authorizenet&view=paymentgateway&task=paymentgateway.cancelTransaction';
		}

		$fields = array();
		if (count((array)$submitData))
		{

			for ($i = 0 ; $i < $index; $i++)
			{
				if (isset($submitData['item_name_' . ($i + 1)])
						&& isset($submitData['quantity_' . ($i + 1)])
						&& isset($submitData['amount_' . ($i + 1)])
						&& isset($submitData['item_number_' . ($i + 1)]))
				{
					$tempNameItem 		= $submitData['item_name_' . ($i + 1)];
					$tempQuantityItem 	= $submitData['quantity_' . ($i + 1)];
					$tempAmountItem 	= $submitData['amount_' . ($i + 1)];

					$tempNumberItem 	= $submitData['item_number_' . ($i + 1)];
					$tempDescItem 		= $submitData['item_name_' . ($i + 1)];

					$tempNameItemExplode = explode(":", $tempNameItem);
					if (count((array)$tempNameItemExplode) > 1)
					{
						$tempNameItem = $tempNameItemExplode[1];
					}
					$fields['x_line_item'][] = 'Item'. ($i + 1) .'<|>' . $this->_characterLimiter($tempNameItem, 30) . '<|>' . $tempDescItem . '<|>' . $tempQuantityItem . '<|>' . $tempAmountItem . '<|>N';
				}
			}
		}


		$currency 		= $params['authorizenet_currency'];
		$apiLoginID 	= $this->_apiLoginID;
		$invoiceNumber 	= $this->_generateInvoiceNumber();
		$clientIP		= $this->_getIP();

		$tstamp 			= time();
		srand(time());
		$sequence 			= rand(1, 10000);

		$dataFingerPrint 	= "$apiLoginID^$sequence^$tstamp^$total^$currency";

		$fingerprint        = $this->_generateSH512($dataFingerPrint, $this->_signatureKey);
		//var_dump($fingerprint);
		//exit();
		//$fingerprint = hash_hmac("sha512", $dataFingerPrint, hex2bin($signatureKey));

		//$fingerprint 		= bin2hex(mhash(MHASH_MD5, $dataFingerPrint, $this->_apiTransactionKey));

		$fields['x_currency_code'] 			= $params['authorizenet_currency'];
		$fields['x_logo_url'] 				= $params['authorizenet_logo'];

		$fields['x_receipt_link_method'] 	= 'POST';
		$fields['x_receipt_link_text'] 		= $params['authorizenet_receipt_link_text'];
		$fields['x_receipt_link_url'] 		= $returnUrl;

		$fields['x_relay_response'] 		= $this->_authorizenetParams['relay_response'];
		$fields['x_relay_url'] 				= $returnUrl;

		$fields['x_method'] 				= 'CC';

		$fields['x_amount'] 				= $total;
		$fields['x_login'] 					= (string) $this->_apiLoginID;

		$fields['x_cancel_url'] 			= $cancelUrl;
		$fields['x_version'] 				= $this->_authorizenetParams['version'];
		$fields['x_fp_sequence'] 			= $sequence;
		$fields['x_fp_timestamp'] 			= $tstamp;
		$fields['x_fp_hash'] 				= $fingerprint;
		$fields['x_show_form'] 				= "PAYMENT_FORM";
		$fields['x_type'] 					= strtoupper($params['authorizenet_transaction_type']);
		$fields['x_invoice_num'] 			= $invoiceNumber;

		if ($params['authorizenet_send_customer_ip'] == '1')
		{
			$fields['x_customer_ip']	= $clientIP;
		}

		/*// Check if extra fee is set?
		if (isset($data['extra_fee_amount']) && $data['extra_fee_amount'] > 0)
		{
			$fields['x_duty'] = $data['extra_fee_amount'];
			$fields['x_amount'] = $data['total_includes_extra_fee'];
		}
		*/

		$fields['x_cust_id'] = uniqid();
		return $fields;

	}

	/**
	 * Check payment gateway is configured correctly
	 * @return bool
	 */
	public function checkPaymentGatewayValid()
	{

		if (@!is_null($this->_paymentConfig->test_mode))
		{
			if ($this->_paymentConfig->test_mode)
			{
				//if((string) $this->_apiMD5Hash == '' || (string) $this->_apiHostname == '' || (string) $this->_apiLoginID == '' || (string) $this->_apiTransactionKey == '')
				if((string) $this->_apiLoginID == '' || (string) $this->_signatureKey == '')
				{
					return false;
				}
			}
			else
			{
				//if ((string) $this->_apiMD5Hash == '' || (string) $this->_apiHostname == '' || (string) $this->_apiLoginID == '' || (string) $this->_apiTransactionKey == '')
				if((string) $this->_apiLoginID == '' || (string) $this->_signatureKey == '')
				{
					return false;
				}
			}
			return true;
		}

		return false;
	}

	/**
	 * Limit the number of string is showed
	 *
	 * @param string $str	The string to be processed
	 * @param number $limit	The number of string is showed
	 * @return string
	 */
	private function _characterLimiter($str, $limit = 0)
	{
		$str = strip_tags(trim($str));

		if (function_exists("mb_substr"))
		{

			$str = mb_substr($str, 0, $limit, 'UTF-8');
		}
		else
		{
			$str = substr($str, 0, $limit);
		}
		return $str;
	}

	/**
	 * Get the field list of a form
	 *
	 * @param int $formID The form ID
	 *
	 * @return ArrayObject;
	 */
	private function _getFormFields($formID)
	{
		$rfields = array();
		$db 	= JFactory::getDbo();
		$query 	= $db->getQuery(true);
		$query->select('*');
		$query->from('#__jsn_uniform_fields');
		$query->where('form_id='. (int) $formID);
		$db->setQuery($query);
		$fields = $db->loadObjectList();

		if (count((array)$fields))
		{
			foreach ($fields as $field)
			{
				$rfields[$field->field_id] = $field->field_settings;
			}
		}

		return $rfields;
	}

	/**
	 * Generate Invoice Number
	 * @return string
	 */
	private function _generateInvoiceNumber()
	{
		$length		 	= 4;
		$chars		  	= 'abcdefghijklmnopqrstuvwxyz';
		$chars_length 	= (strlen($chars) - 1);
		$string		 	= $chars[rand(0, $chars_length)];
		for ($i	= 1; $i < $length; $i = strlen($string))
		{
			$r  = $chars[rand(0, $chars_length)];
			if ($r != $string[$i - 1])
				$string .= $r;
		}
		$fullString = dechex(time() + mt_rand(0, 10000000)) . $string;
		$result	  = strtoupper(substr($fullString, 2, 10));
		return $result;
	}

	/**
	 * Get Client IP
	 *
	 * @return string
	 */
	private function _getIP()
	{
		if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
		{
			$rip = getenv("HTTP_CLIENT_IP");
		}
		else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
		{
			$rip = getenv("HTTP_X_FORWARDED_FOR");
		}
		else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
		{
			$rip = getenv("REMOTE_ADDR");
		}
		else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
		{
			$rip = $_SERVER['REMOTE_ADDR'];
		}
		else
		{
			$rip = "255.255.255.255";
		}
		return $rip;
	}

	/**
	 * Method to verify payment status.
	 *
	 * @param   array  $post  The verifed data
	 *
	 * @return  bool  true/false
	 */
	public function verifyGatewayResponse($post)
	{
	    // verify transaction comes from authorize.net
	    $responseCode	= (int) $post['x_response_code'];
	    if ($responseCode == 1 || $responseCode == 4)
	    {
	        $apiLoginID 		= $this->_apiLoginID;
	        //$apiTransactionKey 	= $this->_apiTransactionKey;
	        //$apiMD5Hash			= $this->_apiMD5Hash;
	        //$md5 				= $post['x_MD5_Hash'];
	        $sha2 				= $post['x_SHA2_Hash'];
	        $transID 			= $post['x_trans_id'];
	        $amount 			= $post['x_amount'];
	        //$myMD5 				= strtoupper(md5("$apiMD5Hash$apiLoginID$transID$amount"));

	        // calculate NEW HMAC SHA-512 hash
	        $hashParams = array(
	            "x_trans_id",
	            "x_test_request",
	            "x_response_code",
	            "x_auth_code",
	            "x_cvv2_resp_code",
	            "x_cavv_response",
	            "x_avs_code",
	            "x_method",
	            "x_account_number",
	            "x_amount",
	            "x_company",
	            "x_first_name",
	            "x_last_name",
	            "x_address",
	            "x_city",
	            "x_state",
	            "x_zip",
	            "x_country",
	            "x_phone",
	            "x_fax",
	            "x_email",
	            "x_ship_to_company",
	            "x_ship_to_first_name",
	            "x_ship_to_last_name",
	            "x_ship_to_address",
	            "x_ship_to_city",
	            "x_ship_to_state",
	            "x_ship_to_zip",
	            "x_ship_to_country",
	            "x_invoice_num",
	        );

	        $hashValues = array();
	        foreach ($hashParams as $hashParam)
	        {
	            if (isset($post[$hashParam]))
	            {
	                $hashValues[] = $post[$hashParam];
	            }
	        }

	        $hashData = "^".implode("^", $hashValues)."^";

	        $ourSHA2        = $this->_generateSH512($hashData, $this->_signatureKey);

            if ($sha2 == $ourSHA2)
	        {
	            $this->_updatePaymentLog($post);
	            $this->_sendMail($post);
	            return true;
	        }
	    }
	    return false;
	}

	/**
	 * Send email
	 *
	 * @param array $post	the post data
	 *
	 * @return boole
	 */
	private function _sendMail($post)
	{
		if (!class_exists('JSNUniFormEmailHelper')) return false;
		// only send email when transaction done

		if (isset($this->_paymentConfig->receive_confirmation_of_successful_transaction))
		{
			if ($this->_paymentConfig->receive_confirmation_of_successful_transaction == '1')
			{
				$objJSNUniFormEmailHelper = new JSNUniFormEmailHelper;
				$objJSNUniFormEmailHelper->prepareDataForEmail($post);
			}
		}

		return true;
	}

	/**
	 * Update transaction log. Set status, amount, currency
	 * @param array $post
	 *
	 */
	private function _updatePaymentLog($post)
	{
		///Authorize.net not return x_currency_code. So we need query our database
		$params 			= (array) $this->_paymentConfig;
		$authorizeCurrency 	= $params['authorizenet_currency'];

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$fields = array(
				$db->quoteName('log_status') . ' = ' . $db->quote('successful'),
				$db->quoteName('log_amount') . ' = ' . $db->quote($post['x_amount']),
				$db->quoteName('log_currency') . ' = ' . $db->quote($authorizeCurrency)
		);
		$conditions = array(
				$db->quoteName('submission_id') . ' = ' . $post['submission_id']
		);
		$query->update($db->quoteName("#__jsn_uniform_payment_authorizenet_logs"));
		$query->set($fields);
		$query->where($conditions);
		$db->setQuery($query);
		$db->execute();
	}

	private function _generateSH512($textToHash, $signatureKey)
	{
	    if ($textToHash != null && $signatureKey != null)
	    {
	        $sig = hash_hmac('sha512', $textToHash, hex2bin($signatureKey));
	        return strtoupper($sig);
	    }
        return false;
	}
}

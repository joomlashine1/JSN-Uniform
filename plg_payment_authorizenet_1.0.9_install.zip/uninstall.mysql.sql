DROP TABLE IF EXISTS `#__jsn_uniform_payment_authorizenet_logs`;

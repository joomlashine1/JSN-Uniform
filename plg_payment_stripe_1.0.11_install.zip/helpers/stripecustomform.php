<?php
/**
 * @version    $Id$
 * @package    JSN_Uniform
 * @author     JoomlaShine Team <support@joomlashine.com>
 * @copyright  Copyright (C) @JOOMLASHINECOPYRIGHTYEAR@ JoomlaShine.com. All Rights Reserved.
 * @license    GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Websites: http://www.joomlashine.com
 * Technical Support:  Feedback - http://www.joomlashine.com/contact-us/get-support.html
 */

defined('_JEXEC') or die('Restricted access');

class JSNUFPayment_StripeHelperStripeCustomForm
{
	private $_apiSecretKey = '';

	private $_apiPublishableKey = '';

	private $_currency = array();

	/**
	 * Contructor
	 * @param array $_currency			The currency list
	 * @param object $_paymentConfig	The payment configuration
	 */
	public function __construct($_currency, $_paymentConfig)
	{
		$this->_paymentConfig = $_paymentConfig;

		$this->_currency = $_currency;

		if (@$this->_paymentConfig->test_mode)
		{
			$this->_apiSecretKey 		= $this->_paymentConfig->stripe_sandbox_secret_key;
			$this->_apiPublishableKey 	= $this->_paymentConfig->stripe_sandbox_publishable_key;
		}
		else
		{
			$this->_apiSecretKey 		= $this->_paymentConfig->stripe_live_secret_key;
			$this->_apiPublishableKey 	= $this->_paymentConfig->stripe_live_publishable_key;
		}
	}

	/**
	 *	Insert Payment Log
	 *
	 * @param (int) $sub_id		The submission ID
	 *
	 * @return void
	 */
    public function insertPaymentLog($sub_id)
    {
    	$params = (array) $this->_paymentConfig;
    	$db = JFactory::getDbo();
        $query = $db->getQuery(true);
        $query->insert($db->quoteName("#__jsn_uniform_payment_stripe_logs"));
        $query->columns($db->quoteName(array('submission_id', 'log_currency')));
        $query->values(implode(',', array($sub_id, $db->quote($params['stripe_currency']))));
        $db->setQuery($query);
        $db->execute();
    }

	/**
	 * Post data to  Payment Gateway
	 *
	 * @param ArrayObject $data			the date are posted to payment gateway
	 * @param ArrayObject $dataField	the field list
	 * @param int $submissionID	The submission ID
	 *
	 * @return bool
	 */
	public function processToPostPaymentGateway($data, $dataField, $submissionID)
	{
		$data 		= $this->_prepareData($data, $dataField, $submissionID);
		$this->insertPaymentLog($submissionID);
		echo $this->_renderStripeCustomForm($data);
		return true;
	}

	/**
	 * Render HTML form to post to Payment Gateway
	 *
	 * @param array $data	The data to render into html
	 * @return string
	 */
	private function _renderStripeCustomForm($data)
	{
		$params 					= (array) $this->_paymentConfig;

		$lang 						= JFactory::getLanguage();
		$lang->load('plg_uniform_payment_stripe', JPATH_BASE . '/administrator');
		$joomlaJqueryFilePath 		= JPATH_ROOT . '/media/jui/js/jquery.min.js';
		$jquery 					= '';
		$archiveCancelTransaction 	= 'var archiveCancelTransaction = false;';
		$collectBillAndZipcode		= 'true';

		if (file_exists($joomlaJqueryFilePath))
		{
			$jquery = JUri::root() . 'media/jui/js/jquery.min.js';
		}
		else
		{
			$jquery = JUri::root() . 'plugins/system/jsnframework/assets/3rd-party/jquery/jquery.min.js';
		}

		if (!isset($params['archive_cancel_transaction']) || $params['archive_cancel_transaction'] == "1")
		{
			$archiveCancelTransaction = 'var archiveCancelTransaction = true;';
		}
		else
		{
			$archiveCancelTransaction = 'var archiveCancelTransaction = false;';
		}

		if (isset($params['stripe_collect_bill_and_zipcode']))
		{
			if ($params['stripe_collect_bill_and_zipcode'] == "0")
			{
				$collectBillAndZipcode = 'false';
			}
		}

		$html = '<script type="text/javascript" src="' . $jquery . '"></script>';
		$html .= '<script type="text/javascript" src="https://checkout.stripe.com/checkout.js"></script>';
		$html .= "<script type=\"text/javascript\">
			" . $archiveCancelTransaction . "
			var tripeTokenKey = null;
			var handler = StripeCheckout.configure({
				key: '" .  $this->_apiPublishableKey . "',
				image: '" . $params['stripe_logo'] . "',
				locale: 'auto',
				allowRememberMe: false,
				zipCode: " . $collectBillAndZipcode . ",
				billingAddress: " . $collectBillAndZipcode . ",
				currency:'" . (string) $data['currency_code'] . "',
				token: function(token, args) {
					tripeTokenKey = token;
					var tripeCustomForm = $('#jsnuf-tripeCustomForm');
					$('#tripe-token-key').val(token.id);
					$('#tripe-email').val(token.email);
					tripeCustomForm.submit();
				},
				opened: function() {
					$('.jsn-modal-overlay', window.parent.document).remove();
					$('.jsn-modal-indicator', window.parent.document).remove();
				},
				closed: function(token) {
					if (tripeTokenKey == null && archiveCancelTransaction == false)
					{
						$.ajax({
							type: 'GET',
							dataType: 'json',
							url: '" . $data['cancel_url'] . "',
							success: function (response) {
								$('#jsn-form-target', window.parent.document).remove();
							},
							error: function (jqXHR, textStatus, errorThrown) {
								$('#jsn-form-target', window.parent.document).remove();
							}
						});
					}
					else
					{
						setTimeout(function() { $('#jsn-form-target', window.parent.document).remove(); } , 500);
					}
				}
			});

			(function($){
				$(window).load(function ()
				{
					$('#jsn-form-target', window.parent.document).css({
                    	'display': 'block',
						'position': 'fixed',
						'height': '100%',
						'width': '100%',
						'bottom': 0
                    });

				    handler.open({
				      name: '" . addslashes((string) $params['stripe_name']) . "',
				      description: '" . addslashes((string) $params['stripe_description']) . "',
				      amount: " . $data['amount'] . "
				    });

				});
				// Close Checkout on page navigation:
				$(window).on('popstate', function() {
					handler.close();
				});
			})(jQuery)
		</script>";
		$html .= '<form action="'.$data['return_url'].'" method="post" id="jsnuf-tripeCustomForm" target="_parent">';
		$html .= '<input type="hidden" name="tripe_tokenkey" id="tripe-token-key" value="">';
		$html .= '<input type="hidden" name="tripe_amount" value="' . $data['amount'] . '">';
		$html .= '<input type="hidden" name="tripe_currency" value="' . (string) $data['currency_code'] . '">';
		$html .= '<input type="hidden" name="tripe_email" id="tripe-email" value="">';
		$html .= '</form>';
		echo '<link rel="stylesheet" href="'. JURI::base() .'/plugins/uniform/payment_stripe/assets/css/jsnpayment_stripe.css">';

		return $html;
	}

	/**
	 * prepare and process data before submit to Payment Gateway
	 * @param array $data
	 *
	 * @return array
	 */
	private function _prepareData($data, $dataField, $subId)
	{
		$params 		= (array) $this->_paymentConfig;
		$submitData 	= array();
		$curencyData 	= $this->_currency[$params['stripe_currency']];

		$curencyFormat 	= new JSNUniFormCurrencyHelper($params['stripe_currency'], $curencyData['currency_decimals'], $curencyData['currency_decimal_symbol'], $curencyData['currency_thousands_separator'], $curencyData['currency_symbol'], $params['stripe_position_symbol']);
		$total 			= (float) $data['jsn_form_total_money']['form_payment_money_value'];

		$config 	= JFactory::getConfig();
		$secret 	= $config->get('secret');
		$token 		= JSession::getFormToken();
		$returnUrl 	= JURI::base() . 'index.php?option=com_uniform&form_id=' . $data['form_id'] . '&secret_key=' . md5($secret) . '&method=payment_stripe&view=paymentgateway&task=paymentgateway.postback&submission_id=' . $subId;
		$cancelUrl 	= JURI::base() . 'index.php?option=com_uniform&form_id=' . $data['form_id'] . '&submission_id=' . $subId . '&secret_key=' . md5($secret) . '&' . $token . '=1' . '&method=payment_stripe&view=paymentgateway&task=paymentgateway.cancelTransaction';

		$fields = array();
		$fields['currency_code']	= $params['stripe_currency'];
		//$fields['amount']			= $data['subtotal_amount'];
		$fields['amount']			= $total* 100;
		$fields['return_url']		= $returnUrl;
		$fields['cancel_url']		= $cancelUrl;

		// Check if extra fee is set?
		/*if (isset($data['extra_fee_amount']) && $data['extra_fee_amount'] > 0)
		{
			$fields['amount'] = $data['total_includes_extra_fee'];
		}*/

		return $fields;

	}

	/**
	 * Check payment gateway is configured correctly
	 * @return bool
	 */
	public function checkPaymentGatewayValid()
	{

		if (@!is_null($this->_paymentConfig->test_mode))
		{
			if ($this->_paymentConfig->test_mode)
			{
				if((string) $this->_apiSecretKey == '' || (string) $this->_apiPublishableKey == '')
				{
					return false;
				}
			}
			else
			{
				if ((string) $this->_apiSecretKey == '' || (string) $this->_apiPublishableKey == '')
				{
					return false;
				}
			}
			return true;
		}

		return false;
	}

	/**
	 * Limit the number of string is showed
	 *
	 * @param string $str	The string to be processed
	 * @param number $limit	The number of string is showed
	 * @return string
	 */
	private function _characterLimiter($str, $limit = 0)
	{
		$str = strip_tags(trim($str));

		if (function_exists("mb_substr"))
		{

			$str = mb_substr($str, 0, $limit, 'UTF-8');
		}
		else
		{
			$str = substr($str, 0, $limit);
		}
		return $str;
	}

	/**
	 * Get the field list of a form
	 *
	 * @param int $formID The form ID
	 *
	 * @return ArrayObject;
	 */
	private function _getFormFields($formID)
	{
		$rfields = array();
		$db 	= JFactory::getDbo();
		$query 	= $db->getQuery(true);
		$query->select('*');
		$query->from('#__jsn_uniform_fields');
		$query->where('form_id='. (int) $formID);
		$db->setQuery($query);
		$fields = $db->loadObjectList();

		if (count((array)$fields))
		{
			foreach ($fields as $field)
			{
				$rfields[$field->field_id] = $field->field_settings;
			}
		}

		return $rfields;
	}

	/**
	 * Generate Invoice Number
	 * @return string
	 */
	private function _generateInvoiceNumber()
	{
		$length		 	= 4;
		$chars		  	= 'abcdefghijklmnopqrstuvwxyz';
		$chars_length 	= (strlen($chars) - 1);
		$string		 	= $chars[rand(0, $chars_length)];
		for ($i	= 1; $i < $length; $i = strlen($string))
		{
			$r  = $chars[rand(0, $chars_length)];
			if ($r != $string[$i - 1])
				$string .= $r;
		}
		$fullString = dechex(time() + mt_rand(0, 10000000)) . $string;
		$result	  = strtoupper(substr($fullString, 2, 10));
		return $result;
	}

	/**
	 * Get Client IP
	 *
	 * @return string
	 */
	private function _getIP()
	{
		if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
		{
			$rip = getenv("HTTP_CLIENT_IP");
		}
		else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
		{
			$rip = getenv("HTTP_X_FORWARDED_FOR");
		}
		else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
		{
			$rip = getenv("REMOTE_ADDR");
		}
		else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
		{
			$rip = $_SERVER['REMOTE_ADDR'];
		}
		else
		{
			$rip = "255.255.255.255";
		}
		return $rip;
	}

	/**
	 * Method to verify payment status.
	 *
	 * @param   array  $post  The verifed data
	 *
	 * @return  bool  true/false
	 */
	public function verifyGatewayResponse($post)
	{
		require_once JPATH_ROOT. '/plugins/uniform/payment_stripe/libraries/stripe/stripe.php';
		// verify transaction comes from Stripe
		$responseToken = (string) $post['tripe_tokenkey'];
		if ($responseToken != '')
		{
			try
			{
				\Stripe\Stripe::setApiKey($this->_apiSecretKey);
				$charge = \Stripe\Charge::create(array(
							"amount" => $post['tripe_amount'], // amount in cents, again
							"currency" => strtolower($post['tripe_currency']),
							"source" => $responseToken,
							"description" => $post['tripe_email'],
				            "receipt_email" => $post['tripe_email'],
							));
				if ($charge->paid == true)
				{
					$this->_updatePaymentLog($post);
					$this->_sendMail($post);
					return true;
				}
			}
			catch (Exception $e)
			{
				return false;
			}

		}

		return false;
	}

	/**
	 * Send email
	 *
	 * @param array $post	the post data
	 *
	 * @return boole
	 */
	private function _sendMail($post)
	{
		if (!class_exists('JSNUniFormEmailHelper')) return false;
		// only send email when transaction done

		if (isset($this->_paymentConfig->receive_confirmation_of_successful_transaction))
		{
			if ($this->_paymentConfig->receive_confirmation_of_successful_transaction == '1')
			{
				$objJSNUniFormEmailHelper = new JSNUniFormEmailHelper;
				$objJSNUniFormEmailHelper->prepareDataForEmail($post);
			}
		}

		return true;
	}

	/**
	 * Update transaction log. Set status, amount, currency
	 * @param array $post
	 *
	 */
	private function _updatePaymentLog($post)
	{
		$db = JFactory::getDbo();
		$query = $db->getQuery(true);

		$fields = array(
				$db->quoteName('log_status') . ' = ' . $db->quote('successful'),
				$db->quoteName('log_amount') . ' = ' . $db->quote($post['tripe_amount']),
				$db->quoteName('log_currency') . ' = ' . $db->quote($post['tripe_currency'])
		);
		$conditions = array(
				$db->quoteName('submission_id') . ' = ' . $post['submission_id']
		);
		$query->update($db->quoteName("#__jsn_uniform_payment_stripe_logs"));
		$query->set($fields);
		$query->where($conditions);
		$db->setQuery($query);
		$db->execute();
	}
}

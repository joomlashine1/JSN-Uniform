DROP TABLE IF EXISTS `#__jsn_uniform_payment_stripe_logs`;

ALTER TABLE `#__jsn_uniform_forms` ADD `form_hide_captcha_if_logged_in` tinyint(1) unsigned NOT NULL DEFAULT '0';
ALTER TABLE `#__jsn_uniform_form_pages` ADD `ordering` INT(11) NOT NULL DEFAULT '0';